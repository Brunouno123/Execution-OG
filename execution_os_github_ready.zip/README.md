# Execution OS™ — Founder Dealer Demo

A standalone, static, fictional dealer demonstration. No live dealership or CRM integration.

## GitHub Pages deployment
1. In `Brunouno123/execution-os-demo`, upload `index.html` to the repository root on `main` (replace the existing file if present).
2. Commit the change.
3. Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
4. Visit https://brunouno123.github.io/execution-os-demo/ and hard-refresh.
5. Test every tab, the activation switch, interventions, training, owner dashboard, OYI slider, ROI slider, audit CSV export and reset on your iPhone.

**Important:** All financial values and outcomes are synthetic scenarios. A workflow intervention is not automatically a sale. This is not a production integration.
